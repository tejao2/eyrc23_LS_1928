# Once the CoppeliaSim ChildScripts are working, copy the child script for "Pendulum C" and paste it here.
