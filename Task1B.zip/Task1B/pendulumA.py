# Once the CoppeliaSim ChildScripts are working, copy the child script for "Pendulum A" and paste it here.
