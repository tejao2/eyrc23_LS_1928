# Once the CoppeliaSim ChildScripts are working, copy the child script for "Pendulum B" and paste it here.
