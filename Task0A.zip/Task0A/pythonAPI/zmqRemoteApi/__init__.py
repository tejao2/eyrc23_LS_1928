import sys
sys.path.append('..')
from src.coppeliasim_zmqremoteapi_client import *
print('warning: import zmqRemoteApi is deprecated. Please use import coppeliasim_zmqremoteapi_client instead.')
